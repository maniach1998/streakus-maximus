const URI = process.env.MONGODB_URI;

export const mongoConfig = {
	URI,
};
